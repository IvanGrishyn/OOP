#include "telecast.hpp"
#include <ext/slist>

class TTVProg{
public:
		TTVProg();
     		TTVProg(char* file_name);
	     ~TTVProg();
		int Save(char* file_name);
		int AddCast(TMyDate date);
		int Verify(void);
		void Print();
		int Print(TMyDate date);
		int Show(TMyDate date);
private: 
                __gnu_cxx::slist<TTelecast> casts;
		
};
