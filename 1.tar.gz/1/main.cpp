//Лабораторная работа №1  Иванов Г.А. гр. КМ-19

#include <iostream>
#include "1.hpp" // описание структур


int main() // работа с функциями
{

 using namespace  std;


Fraction fract1(Fill); //создаем и заполняем экземпляры дробей 
Fraction fract2(Fill);
Fraction fract3(Empty); //создаем пустую дробь для  результатов (инициализация значением не нужна))

Functions func1; //создаем экземпляр класса с методами функций

cout<<"Сумма дробей:";
fract3 = func1.Add(fract1,fract2);
fract3=func1.Simplify(fract3);
fract3.print(); CR;

cout<<"Разность дробей:";
fract3 = func1.Sub(fract1,fract2);
fract3=func1.Simplify(fract3);
fract3.print(); CR;

cout<<"Произведение дробей:";
fract3 = func1.Mul(fract1,fract2);
fract3=func1.Simplify(fract3);
fract3.print(); CR;

cout<<"Частное дробей:";
fract3 = func1.Div(fract1,fract2);
fract3=func1.Simplify(fract3);
fract3.print(); CR;



cout<<"The End!"; CR;
    return 0; 
}
