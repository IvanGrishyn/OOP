
#include <iostream>
#include "1.hpp" // описание структур

 

int  Functions::NOD(int a, int b){ /*Нахождение НОД по алгоритму Евклида
Найдём наибольший общий делитель чисел  140  и  96:
1) 140 : 96 = 1 (остаток 44)
2) 96 : 44 = 2 (остаток 8)
3) 44 : 8 = 5 (остаток 4)
4) 8 : 4 = 2
Последний делитель равен  4  — это значит:
НОД (140, 96) = 4.*/
int t;
if (b>a) {t=a;a=b;b=t;} //а должно быть больше b
do  { 
t=b;  //сохраняем делитель               
b=a%b; //остаток в делитель
a=t;//делитель в делимое
} while (b); /*если остаток нулевой,
то наименьший общий делитель найден*/ return a;}

Fraction Functions::Add(Fraction a, Fraction b) // Сложение дробей (по заданию) 
{
Fraction c(Empty);//Создаем пустой класс для вычислений
int NOK=a.fraction.denominator*b.fraction.denominator/Functions::NOD(a.fraction.denominator,b.fraction.denominator);/*
Вычисляем наименьшее общее кратное*/
int amA=NOK/a.fraction.denominator;//дополнительный множитель для первой
int amB=NOK/b.fraction.denominator;//и второй дроби
c.fraction.numerator=a.fraction.numerator*amA+b.fraction.numerator*amB;/*складываем числители дробей 
с домножением на дополнительные множители и заносим в числитель*/
c.fraction.denominator=NOK;//знаменатель это наименьшее общее кратное
return c;
}

Fraction Functions::Sub(Fraction a, Fraction b)// Вычитание дробей (по заданию)
{  Fraction c(Empty);//Создаем пустой класс для вычислений
int NOK=a.fraction.denominator*b.fraction.denominator/Functions::NOD(a.fraction.denominator,b.fraction.denominator);/*
Вычисляем наименьшее общее кратное*/
int amA=NOK/a.fraction.denominator;//дополнительный множитель для первой
int amB=NOK/b.fraction.denominator;//и второй дроби
c.fraction.numerator=a.fraction.numerator*amA-b.fraction.numerator*amB;/*вычитаем числители дробей 
с домножением на дополнительные множители и заносим в числитель*/
c.fraction.denominator=NOK;//знаменатель это наименьшее общее кратное
return c;}

Fraction Functions::Simplify(Fraction a)// Упрощается ли дробь?
{  Fraction c(Empty);//Создаем пустой класс для вычислений
c=a;
bool s2=false;
bool s3=false;
do {
if (c.fraction.denominator%2+c.fraction.numerator%2) s2=false; else 
{c.fraction.denominator/=2; c.fraction.numerator/=2; }
if  (c.fraction.denominator%3+c.fraction.numerator%3) s3=false;  else 
{c.fraction.denominator/=3; c.fraction.numerator/=3; } 
}while  (s2+s3);
return c;}

Fraction Functions::Mul(Fraction a, Fraction b) //Умножение дробей (по заданию)
{ Fraction c(Empty);//Создаем пустой класс для вычислений
c.fraction.numerator=a.fraction.numerator*b.fraction.numerator;//умножаем числители дробей и заносим в числитель
c.fraction.denominator=a.fraction.denominator*b.fraction.denominator;//тоже самое для знаменателей
return c;}//возвращаем результат


Fraction Functions::Div(Fraction a, Fraction b) //Вычитание дробей (по заданию)
{Fraction c(Empty);//создаем пустой класс для вычислений
c.fraction.numerator=a.fraction.numerator*b.fraction.denominator;//умножаем числитель 1 й дроби на знаменатель 2й
c.fraction.denominator=a.fraction.denominator*b.fraction.numerator;//умножаем знаменатель 1й дроби на числитель 2й
return c;}//возвращаем результат

Functions::Functions(){}//конструктор с деструктором пока не нужны
Functions::~Functions(){}

void Fraction::print(){std::cout<<fraction.numerator<<"/"<<fraction.denominator; CR;
}
Fraction::Fraction(bool isEmpty)//конструктор
{//std::cout<<"This is constructooor!"<<std::endl;
if (isEmpty) {
std::cout << "Введите числитель-" ;
try { std::cin>>fraction.numerator;}
catch(const char *msg) {std::cout << msg;}  CR;
std::cout << "Введите знаменатель-";    
try {  std::cin>> fraction.denominator;}
catch(const char *msg) {std::cout << "Ошибка!";} CR;
}}

Fraction::~Fraction(){}//Деструктор
