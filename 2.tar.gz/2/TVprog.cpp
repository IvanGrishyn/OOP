#include"TVprog.hpp"
#include"fast-cpp-csv-parser/csv.h"
#include <iostream>
#include <fstream> 

TTVProg::TTVProg() {
TTelecast cast;}
      	
TTVProg::TTVProg(char* file_name){
TTelecast cast;
 io::CSVReader<8, io::trim_chars<>,io::no_quote_escape<';'>> in(file_name);
  in.read_header(io::ignore_extra_column, "title","duration","yy","mn","dd","hh","mm","ss");
  std::string title;
  int duration,yy,mn,dd,hh,mm,ss;
  while(in.read_row(title, duration, yy,mn,dd,hh,mm,ss)){
  std::cout<<"Дoбавлено-"<<title<<" "<<duration<<" "<<yy<<"y"<<mn<<"m"<<dd<<"d"<<hh<<"h"<<mm<<"m"<<ss<<" s\n";
 cast.Name=title; cast.duration=duration;cast.when.yy=yy;cast.when.mn=mn;cast.when.dd=dd;cast.when.hh=hh;cast.when.mm=mm;cast.when.ss=ss;
 casts.push_front(cast);  
   }
}
	  
TTVProg::~TTVProg(){
std::cout<<"Желаете сохранить телепрограмму перед выходом(y/n)?\n";
char choise[12];
std::cin>>choise; 
if (strcmp(choise, "y")==0) {std::cout<<"Задайте имя файла:";
std::cin>>choise; 
TTVProg::Save(choise);}
casts.clear();
}
	
int TTVProg::Show(TMyDate date){return 0;}

int TTVProg::Save(char* file_name){

  std::fstream fs;
  TTelecast cast;

   strcat(file_name,".csv");

  fs.open (file_name, std::fstream::in | std::fstream::out | std::fstream::app);

  fs <<"title;duration;yy;mn;dd;hh;mm;ss\n" ;
for (auto iter = casts.begin(); iter != casts.end(); iter++){
cast=*iter;
fs<<cast.Name<<";"<<cast.duration<<";"<<cast.when.yy<<";"<<cast.when.mn<<";"<<cast.when.dd<<";"
<<cast.when.hh<<";"<<cast.when.mm<<";"<<cast.when.ss<<";\n";
};


  fs.close();
return 0;}

int TTVProg::AddCast(TMyDate date){return 0;}

int TTVProg::Verify(void){return 0;}

void TTVProg::Print(){}

int TTVProg::Print(TMyDate date){return 0;}

