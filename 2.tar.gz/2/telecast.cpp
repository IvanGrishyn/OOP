#include "telecast.hpp"


TTelecast::TTelecast(){}

TTelecast::TTelecast(TMyDate when, Channels where, char* Name) {}
