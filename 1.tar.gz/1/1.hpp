#define Empty 0
#define Fill 1
#define CR std::cout<<std::endl


class Fraction
{
public:
	Fraction(bool isEmpty); //constructor
     ~Fraction();//destructor
        void print();//вывод дроби
        struct {  int numerator, denominator;} fraction; //Согласно заданию лабораторной
};

class Functions
{public:
	Functions();//constructor
     ~Functions();//destructor
     	Fraction Add(Fraction a, Fraction b); //Сложение дробей (по заданию)
        Fraction Sub(Fraction a, Fraction b); // Вычитание дробей (по заданию)
        Fraction Mul(Fraction a, Fraction b); //Умножение дробей (по заданию)
        Fraction Div(Fraction a, Fraction b); //Вычитание дробей (по заданию)
        Fraction Simplify(Fraction a); //Упростить

	private:        
        int NOD(int a, int b);
     
};


