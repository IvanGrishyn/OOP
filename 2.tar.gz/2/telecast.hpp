#include <string>

struct TMyDate{
int yy,mn,dd,hh,mm,ss;
};

enum Channels{
CHANNEL_ONE,
CHANNEL_LAVENSARY,
CHANNEL_UT1,
};


class TTelecast {

public: TTelecast();
		TTelecast(TMyDate when, Channels where, char* Name);
		TMyDate when;
		std::string Name;
		int duration;


} ;
